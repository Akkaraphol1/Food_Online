import java.awt.*;
import java.awt.event.*;
import javax.swing.*;


public class Search extends JFrame implements ActionListener  {
  
private static JButton Food,Drink,Seafood;
   private static JButton Member2;
   private JButton Search3,AM;;
   private static JButton Location;
   private JButton Officer4;
   private JButton History;
   private static JButton Back,hide,next1;
   JLabel Lm;
   public JLabel img;
   
 //New3
   private static String SHOW_ACTION = "show";
   private static String HIDE_ACTION = "hide";
   private static String NEXT_ACTION = "next";
   private static String NEXT2_ACTION = "next2";
   
   private Image image = null;
   private boolean showImage = false;
  
   
  public Search(String filename){
	   
	   getContentPane().setLayout(null);
	  //New3
	 
	
	   Food = new JButton("Food");
	   Food.setFont(new Font("Serif", Font.BOLD, 30));
	   Food.addActionListener(this);
       Food.setActionCommand(SHOW_ACTION);
	   Food.setBounds(120, 74, 95, 30);
	   Food.setSize(170,80);
		getContentPane().add(Food);
			
		Seafood = new JButton("Seafood");
		Seafood.setFont(new Font("Serif", Font.BOLD, 30));
		Seafood.addActionListener(this);
        Seafood.setActionCommand(NEXT_ACTION);	
	    Seafood.setBounds(120, 145, 95, 30);
	    Seafood.setSize(170,80);
		getContentPane().add(Seafood);
				
		Search3 = new JButton("Search");
		Search3.setFont(new Font("Serif", Font.BOLD, 30));
		Search3.setBounds(120, 215, 95, 30);
	    Search3.setSize(170,80);
		getContentPane().add(Search3);
		
		Officer4 = new JButton("Officer");
		Officer4.setFont(new Font("Serif", Font.BOLD, 30));
		Officer4.setBounds(120, 285, 95, 30);
	    Officer4.setSize(170,80);
		getContentPane().add(Officer4);
		
		Location = new JButton("Location");
		Location.setFont(new Font("Serif", Font.BOLD, 30));
		Location.setBounds(120, 355, 95, 30);
	    Location.setSize(170,80);
		getContentPane().add(Location);
		
		History = new JButton("History");
		History.setFont(new Font("Serif", Font.BOLD, 30));
		History.setBounds(120, 425, 95, 30);
	    History.setSize(170,80);
		getContentPane().add(History);
		
		Back = new JButton("Back");
		Back.setFont(new Font("Serif", Font.BOLD, 30));
		Back.setBounds(120, 495, 95, 30);
	    Back.setSize(170,80);
		getContentPane().add(Back);
		
		hide = new JButton("Hide");
		hide.setFont(new Font("Serif", Font.BOLD, 30));
		hide.addActionListener(this);
        hide.setActionCommand(HIDE_ACTION);
		hide.setBounds(120, 570, 95, 30);
        hide.setSize(170,80);
		getContentPane().add(hide);
		
		next1 = new JButton("Next");
		next1.setFont(new Font("Serif", Font.BOLD, 30));
		next1.addActionListener(this);
        next1.setActionCommand(NEXT2_ACTION);
		next1.setBounds(500, 870, 95, 30);
        next1.setSize(170,50);
		getContentPane().add(next1);
		
		
	   Seafood.addActionListener(new ButtonListener());
	   Search3.addActionListener(new ButtonListener());
	   Officer4.addActionListener(new ButtonListener());
	  Location.addActionListener(new ButtonListener()); 
	  History.addActionListener(new ButtonListener());
	  Back.addActionListener(new ButtonListener());
	  hide.addActionListener(new ButtonListener());
	  next1.addActionListener(new ButtonListener());
   }
		
 
public void paint(Graphics g){
     super.paint(g);
     g.setColor(Color.blue);
     g.drawRect(120, 100, 1600, 860); 
     g.setColor(Color.red);
     g.drawRect(300,112, 1410, 795); 

     //New3
     if (showImage) {
         g.drawImage(image, 305, 115, image.getWidth(null), image.getHeight(null), null);
     }
     
     
     
   }

public void actionPerformed(ActionEvent event) {
    String actionCommand = event.getActionCommand();
    
    
   if (SHOW_ACTION.equals(actionCommand)) {
    	 this.image = new ImageIcon("C:/Users/User/workspace/Lab/img/FoodKookSoul3.png").getImage();
        showImage = true;
 
    }
   
   if (NEXT_ACTION.equals(actionCommand)) {
	  	 this.image = new ImageIcon("C:/Users/User/workspace/Lab/img/Menu3.png").getImage();
	      showImage = true;
	  }
   
   else if (NEXT2_ACTION.equals(actionCommand)) {
	  	 this.image = new ImageIcon("C:/Users/User/workspace/Lab/img/unnamed.png").getImage();
	      showImage = true;
	  }

    else if (HIDE_ACTION.equals(actionCommand)) {
    	 showImage = false;
    }
   
  
    repaint();
}
//New3


   public static void main(String[] args){
	  
		  
	   Search window = new Search("Search");
	   window.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
	   window.setSize(1920,1000);
	   window.setVisible(true);
	   window.setLocationRelativeTo(null);
	   
	           
   }

	
   public static class ButtonListener implements ActionListener {

	   

		@Override
		public void actionPerformed(ActionEvent e) {
			
			if (e.getSource() == Back)
			{
				HAG N = new HAG();
				   N.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
				   N.setSize(800,700);
				   N.setVisible(true);
				   N.setLocationRelativeTo(null);
			}
			
			if (e.getSource() == Location)
			{
			
			    	 
			    
			}
			
		}

		
   }
   
	   }
   
   

