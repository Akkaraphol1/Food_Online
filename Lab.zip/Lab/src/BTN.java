
// File Name : Picture.java
import java.awt.*;
import javax.swing.*;
public class BTN {
private Image image;
private int x, y;
public BTN(String fname) {
image = new ImageIcon("C:/Users/User/workspace/Lab/img/unnamed.png").getImage();
}
public void draw( JPanel jPanel ) {
((Icon) image).paintIcon( jPanel , jPanel.getGraphics(), x, y );
}
public void position(int x, int y) {
this.x = x;
this.y = y;
}
public void clear(JPanel jPanel) {
jPanel.paint(jPanel.getGraphics());
}

}
