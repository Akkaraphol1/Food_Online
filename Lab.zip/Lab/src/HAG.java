
import java.awt.*;
import javax.swing.*;
import java.awt.event.*;

public class HAG extends JFrame{
   private JButton Menu;
   private JButton Member;
   private JButton Search;
   private JButton Bill,Manager,Officer;
   public JLabel w;
   
  public HAG(){
	   
	  getContentPane().setLayout(null);
	  
	   JLabel w = new JLabel("Welcome to FoodLand");
		w.setFont(new Font("Serif", Font.BOLD, 42));
		w.setBounds(190, 30, 95, 30);
		w.setSize(500,70);
		getContentPane().add(w);

		
		Menu = new JButton("Search");
	    Menu.setFont(new Font("Serif", Font.BOLD, 30));
	    Menu.setBounds(190, 150, 95, 30);
		Menu.setSize(150,70);
		getContentPane().add(Menu);
		
		Member = new JButton("Member");
		Member.setFont(new Font("Serif", Font.BOLD, 30));
		Member.setBounds(440, 150, 95, 30);
	    Member.setSize(150,70);
		getContentPane().add(Member);
		
		Search = new JButton("Menu");
		Search.setFont(new Font("Serif", Font.BOLD, 30));
		Search.setBounds(190, 300, 95, 30);
	    Search.setSize(150,70);
		getContentPane().add(Search);
		
		Officer = new JButton("Officer");
		Officer.setFont(new Font("Serif", Font.BOLD, 30));
		Officer.setBounds(440, 300, 95, 30);
	    Officer.setSize(150,70);
		getContentPane().add(Officer);
		
		Manager = new JButton("Manager"); 
		Manager.setFont(new Font("Serif", Font.BOLD, 30));
		Manager.setBounds(310, 450, 95, 30);
	    Manager.setSize(150,70);
		getContentPane().add(Manager);
		
	   Menu.addActionListener(new ButtonListener());
	   Member.addActionListener(new ButtonListener());
	   Search.addActionListener(new ButtonListener());
	   Officer.addActionListener(new ButtonListener());
	   Manager.addActionListener(new ButtonListener());
	   
	  
   }
   public void paint(Graphics g){
     super.paint(g);
   }
   public static void main(String[] args){
	   
	   HAG N = new HAG();
	   N.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
	   N.setSize(800,700);
	   N.setVisible(true);
	   N.setLocationRelativeTo(null);
	   
	}	
	
	public class ButtonListener implements ActionListener {

		@Override
		public void actionPerformed(ActionEvent e) {
			if (e.getSource() == Menu)
			{
				Lab7_3 obj = new Lab7_3();
				obj.setVisible(true);
				
			}
			if (e.getSource() == Member)
			{
				register f = new register();
				f.setVisible(true);
				f.setSize(800,700);
				f.setLocationRelativeTo(null);
			}
			if (e.getSource() == Search)
			{
				Search Sn = new Search(null);
				   Sn.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
				   Sn.setSize(1920,1000);
				   Sn.setVisible(true);
				   Sn.setLocationRelativeTo(null);
				   
			}
			if (e.getSource() == Officer)
			{
				 New3 frame = new New3("C:/Users/User/workspace/Lab/img/unnamed.png");
	                frame.setVisible(true);
				
			}
			
		}

	}

}
