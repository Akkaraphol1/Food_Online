
import java.awt.*;
import java.awt.event.*;
import javax.swing.*;

public class Lab7_3 implements ActionListener {
JLabel numberLabel;
JButton btn1, btn2, btn3;
JFrame window;
public Lab7_3() {
// obtain content pane and set its layout to FlowLayout
window = new JFrame("Programm Show Text");
Container container = window.getContentPane();
container.setLayout( new FlowLayout() );
//create numberLabel and attach it to content pane


btn1 = new JButton(" 1 ");
btn1.addActionListener( this);
container.add( btn1 );
btn2 = new JButton(" 2 ");
btn2.addActionListener( this);
container.add( btn2 );
btn3 = new JButton(" 3 ");
btn3.addActionListener( this);
container.add( btn3 );
window.setSize( 800,700);
window.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
window.setVisible(true);
window.setLocationRelativeTo(null);

}
public void actionPerformed( ActionEvent event )
{

if (event.getSource() == btn1) {

    HAG N = new HAG();
    N.setVisible(true);  
    N.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
	N.setSize(800,700);
	N.setLocationRelativeTo(null);
	
}
else if (event.getSource() == btn2) {


}
else if (event.getSource() == btn3) {


}
} // end method actionPerformed

public static void main(String[] args) {
Lab7_3 Gm = new Lab7_3();
}
public static  void setVisible(boolean b) {
	// TODO Auto-generated method stub
	Lab7_3 Gm = new Lab7_3();
}

}