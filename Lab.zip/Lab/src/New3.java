
import java.awt.BorderLayout;
import java.awt.Component;
import java.awt.Container;
import java.awt.EventQueue;
import java.awt.FlowLayout;
import java.awt.Font;
import java.awt.Graphics;
import javax.swing.SpringLayout;
import java.awt.Image;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.WindowConstants;


public class New3 extends JFrame implements ActionListener {

	private static JButton Menu1;
	   private JButton Member2;
	   private JButton Search3;
	   private JButton Location,Officer4,History;
	   JLabel Lm;
	   public JLabel img;
    JButton showButton;	
    
    private static String SHOW_ACTION = "show";

    private Image image = null;
    private boolean showImage = false;

    public New3(String filename) {
    	
    	getContentPane().setLayout(null);
        
        this.image = new ImageIcon("C:/Users/User/workspace/Lab/img/unnamed.png").getImage();

  
        JButton showButton = new JButton("Show");
        showButton.setSize(1000,1000);
        showButton.addActionListener(this);
        showButton.setActionCommand(SHOW_ACTION);
        showButton.setBounds(190,150,95,30);
        getContentPane().add(showButton);
       
      
    }

    @Override
    public void paint(Graphics g) {
        super.paint(g);

        if (showImage) {
            g.drawImage(image, 400, 150, image.getWidth(null), image.getHeight(null), null);
        }
    }

    @Override
    public void actionPerformed(ActionEvent event) {
        String actionCommand = event.getActionCommand();
        

        if (SHOW_ACTION.equals(actionCommand)) {
        	
            showImage = true;
        }
        
        repaint();
    }
  
    public static void main(String[] args) {
        EventQueue.invokeLater(new Runnable() {

            @Override
            public void run() {
            	
                New3 frame = new New3("C:/Users/User/workspace/Lab/img/unnamed.png");
                frame.setTitle("Game");
                frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
				frame.setSize(1280,720);
				frame.setVisible(true);
				frame.setLocationRelativeTo(null);
            }
        });
    }

}

