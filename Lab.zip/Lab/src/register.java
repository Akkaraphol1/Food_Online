
import java.awt.event.WindowEvent; 
import java.awt.BorderLayout;
import java.awt.Component;
import java.awt.Container;
import java.awt.EventQueue;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.Statement;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JButton;
import javax.swing.JTextField;
import java.awt.*;
import javax.swing.*;
import java.awt.event.*;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import javax.swing.SwingConstants;
import java.awt.Font;
import javax.swing.JPasswordField;

public class register extends javax.swing.JFrame {
	
	private static final Container f = null;
	public static final int WINDOW_CLOSING = 0;
	private JTextField txtUsername;
	private JPasswordField txtPassword;
	private JPasswordField txtConfirmPassword;
	private JTextField txtN , txtL ,txtM, txtC;
	private JTextField txtEmail ;
	private JButton Cnl,btnConfirm;
	
	
	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				register f = new register();
				f.setVisible(true);
				f.setSize(800,700);
				f.setLocationRelativeTo(null);
			}
		});
	}
	/**
	 * Create the frame.
	 */
	public register() {
		getContentPane().setLayout(null);
		setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
		setBounds(100, 100, 454, 343);
		setTitle("Register Train");
		
		// Header Title
		JLabel hRs = new JLabel("Register Train");
		hRs.setFont(new Font("Tahoma", Font.BOLD, 40));
		hRs.setHorizontalAlignment(SwingConstants.CENTER);
		hRs.setBounds(121, 11, 132, 20);
	    hRs.setSize(500,60);
		getContentPane().add(hRs);

		// *** Header ***//
		
		JLabel hN = new JLabel("First Name ");
		hN.setFont(new Font("Tahoma", Font.BOLD, 35));
		hN.setBounds(158, 35, 89, 14);
		hN.setSize(500,160);	
		getContentPane().add(hN);
		
		JLabel hL = new JLabel("Last Name  ");
		hL.setFont(new Font("Tahoma", Font.BOLD, 35));
		hL.setBounds(158, 85, 89, 14);
		hL.setSize(500,160);	
		getContentPane().add(hL);
				
		JLabel hUn = new JLabel("Username  ");
		hUn.setFont(new Font("Tahoma", Font.BOLD, 35));
		hUn.setBounds(158, 135, 89, 14);
		hUn.setSize(500,160);	
		getContentPane().add(hUn);
		
		JLabel hPs = new JLabel("Password  ");
		hPs.setFont(new Font("Tahoma", Font.BOLD, 35));
		hPs.setBounds(158, 185, 89, 14);
		hPs.setSize(500,160);	
		getContentPane().add(hPs);
		
		JLabel hCP = new JLabel("Confirm Password ");
		hCP.setFont(new Font("Tahoma", Font.BOLD, 35));
		hCP.setBounds(30, 235, 89, 14);
		hCP.setSize(500,160);	
		getContentPane().add(hCP);

		JLabel hE = new JLabel("Email  ");
		hE.setFont(new Font("Tahoma", Font.BOLD, 35));
		hE.setBounds(158, 285, 89, 14);
		hE.setSize(500,160);	
		getContentPane().add(hE);

		JLabel hP = new JLabel("Mobile Phone  ");
		hP.setFont(new Font("Tahoma", Font.BOLD, 35));
		hP.setBounds(58, 335, 89, 14);
		hP.setSize(500,160);	
		getContentPane().add(hP);
		
		JLabel hCt = new JLabel("Country or Religion  ");
		hCt.setFont(new Font("Tahoma", Font.BOLD, 35));
		hCt.setBounds(28, 385, 89, 14);
		hCt.setSize(500,160);	
		getContentPane().add(hCt);
		
		// First Name
		txtN = new JTextField("");
		txtN.setBounds(388, 105, 89, 14);
		txtN.setSize(250,32);
		getContentPane().add(txtN);

		// Last Name
	    txtL = new JTextField("");
		txtL.setBounds(388, 155, 89, 14);
		txtL.setSize(250,32);
		getContentPane().add(txtL);
				
		// CustomerID
		txtUsername = new JTextField("");
		txtUsername.setBounds(388, 205, 89, 14);
		txtUsername.setSize(250,32);
		getContentPane().add(txtUsername);
		
		// Password
		txtPassword = new JPasswordField();
		txtPassword.setBounds(388, 255, 89, 14);
		txtPassword.setSize(250,32);
		getContentPane().add(txtPassword);
		
		// Confirm Password
		txtConfirmPassword = new JPasswordField();
		txtConfirmPassword.setBounds(388, 305, 89, 14);
		txtConfirmPassword.setSize(250,32);
		getContentPane().add(txtConfirmPassword);

		// Email
		txtEmail = new JTextField("");
		txtEmail.setBounds(388, 355, 89, 14);
		txtEmail.setSize(250,32);
		getContentPane().add(txtEmail);
		
		// Mobile Phone
		txtM = new JTextField("");
		txtM.setBounds(388, 405, 89, 14);
		txtM.setSize(250,32);
		getContentPane().add(txtM);
		
		// Country and Religion
		txtC = new JTextField("");
		txtC.setBounds(388, 455, 89, 14);
		txtC.setSize(250,32);
		getContentPane().add(txtC);
		
		// Confirm Button

		JButton btnConfirm = new JButton("Confirm");
		btnConfirm.setFont(new Font("Tohama", Font.BOLD, 20) );
		 
		btnConfirm.addActionListener(new ButtonListener());
		btnConfirm.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				if(RegisterData()) {
					JOptionPane.showMessageDialog(null,
							"Register Data Successfully");
				   
				}
			}
		});
		
		btnConfirm.setBounds(190, 530, 89, 14);
		btnConfirm.setSize(150,50);
		getContentPane().add(btnConfirm);
		
		Cnl = new JButton("Back");
		Cnl.setFont(new Font("Tohama", Font.BOLD, 20));
		Cnl.setBounds(428, 530, 89, 14);
	    Cnl.setSize(150,50);
		getContentPane().add(Cnl);
		
		Cnl.addActionListener(new ButtonListener());
		
	}
		
	
	
	private Boolean RegisterData()
	{	
		String strN = txtN.getText();
		String strL = txtL.getText();
		String strUsername = txtUsername.getText();
		String strPassword = new String(txtPassword.getPassword());
		String strConfirmPassword = new String(txtConfirmPassword.getPassword());
		String strEmail = txtEmail.getText();
		String strM = txtM.getText();
		String strC = txtC.getText();
		
		if(strN.equals("")) // First Name
		{
			JOptionPane.showMessageDialog(null,
					"Please Input (First Name)");
			txtN.requestFocusInWindow(); 
			return false;
		}	
		
		if(strL.equals("")) // Last Name
		{
			JOptionPane.showMessageDialog(null,
					"Please Input (Last Name)");
			txtL.requestFocusInWindow(); 
			return false;
		}	
		
		if(strUsername.equals("")) // Username
		{
			JOptionPane.showMessageDialog(null,
					"Please Input (Username)");
			txtUsername.requestFocusInWindow(); 
			return false;
		}
		if(strPassword.equals("")) // Password
		{
			JOptionPane.showMessageDialog(null,
					"Please Input (Password)");
			txtPassword.requestFocusInWindow(); 
			return false;
		}
		
		if(strConfirmPassword.equals("")) // Confirm Password
		{
			JOptionPane.showMessageDialog(null,
					"Please Input (Confirm Password)");
			txtConfirmPassword.requestFocusInWindow(); 
			return false;
		}
		if(!strPassword.equals(strConfirmPassword)) // Password math
		{
			JOptionPane.showMessageDialog(null,
					"Please Input (Password Not Match!)");
			txtPassword.requestFocusInWindow(); 
			return false;
		}		
		
		if(strEmail.equals("")) // Email
		{
			JOptionPane.showMessageDialog(null,
					"Please Input (Email)");
			txtEmail.requestFocusInWindow(); 
			return false;
		}	
		
		if(strM.equals("")) // Mobile Phone
		{
			JOptionPane.showMessageDialog(null,
					"Please Input (Mobile Phone)");
			txtM.requestFocusInWindow(); 
			return false;
		}	
		
		if(strC.equals("")) // Country and religion
		{
			JOptionPane.showMessageDialog(null,
					"Please Input (Country and Religion)");
			txtC.requestFocusInWindow(); 
			return false;
		}	
		
		Connection connect = null;
		Statement s = null;
		Boolean status = false;

		try {
			Class.forName("com.mysql.jdbc.Driver");

			connect = DriverManager.getConnection(""
					+ "jdbc:mysql://localhost/mydatabase"
					+ "?user=root&password=root");

			s = connect.createStatement();
			
			// SQL Insert
			String sql = "INSERT INTO member "
					+ "(Username,Password,Email,Name) "
					+ "VALUES ('" + strN + "','"
					+ strL + "','"
					+ strUsername + "','"
					+ strPassword + "','"
					+ strEmail + "'" + ",'"
					+ strM + "','"
					+ strC +  "') ";
			s.execute(sql);
			
			// Reset Text Fields
			txtN.setText("");
			txtL.setText("");
			txtUsername.setText("");
			txtPassword.setText("");
			txtConfirmPassword.setText("");
			txtEmail.setText("");
			txtM.setText("");
			txtC.setText("");
			
			status  = true;

		} catch (Exception e) {
			// TODO Auto-generated catch block
			JOptionPane.showMessageDialog(null, e.getMessage());
			e.printStackTrace();
		}

		try {
			if (s != null) {
				s.close();
				connect.close();
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			System.out.println(e.getMessage());
			e.printStackTrace();
		}
		
		return status;

	}
	
	public class ButtonListener implements ActionListener {

		@Override
		public void actionPerformed(ActionEvent e) {
			if (e.getSource() == Cnl)
			{
				HAG N = new HAG();
				   N.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
				   N.setSize(800,700);
				   N.setVisible(true);
				   N.setLocationRelativeTo(null);
			}
			if (e.getSource() == btnConfirm)
			{
				HAG N = new HAG();
				   N.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
				   N.setSize(800,700);
				   N.setVisible(true);
				   N.setLocationRelativeTo(null);
			}
	}
}
}